$(function() {

		
$('.owl-carousel').owlCarousel({
    loop:true,
	lazyLoad:true,
    margin:4,
	autoplay:true,
    autoplayTimeout:1000,
	touchDrag  : true,
     mouseDrag  : true,
    responsiveClass:true,
    responsive:{
        1366:{
            items:1,
            nav:true
        },
		1024:{
            items:5,
            nav:true
        },
        640:{
            items:2,
            nav:true
        },
		0:{
			items:1,
            nav:true
		}
    }
})
});